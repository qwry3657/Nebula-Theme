#!/system/bin/sh
# Do NOT assume where your module will be located.
# ALWAYS use $MODDIR if you need to know where this script
# and module is placed.
# This will make sure your module will still work
# if Magisk change its mount point in the future
MODDIR=${0%/*}

# This script will be executed in late_start service mode


fonts_customization_mod="/data/system/fonts_customization.xml"
product_fonts_customization="/product/etc/fonts_customization.xml"
system_fonts_customization="/system/etc/fonts_customization.xml"
sa="/product/etc/sa.xml"

if [ -f /data/system/fonts_customization.xml ]; then
	rm -rf $fonts_customization_mod
fi

touch /data/system/fonts_customization.xml

if [ -f /system/etc/fonts_customization.xml ]; then
	cat $system_fonts_customization >> $fonts_customization_mod
	sed -i '/<\/fonts-modification>/d' $fonts_customization_mod
	cat $sa >> $fonts_customization_mod
	mount -o bind $fonts_customization_mod $system_fonts_customization || true

elif [ -f /product/etc/fonts_customization.xml ]; then
	cat $product_fonts_customization >> $fonts_customization_mod
	sed -i '/<\/fonts-modification>/d' $fonts_customization_mod
	cat $sa >> $fonts_customization_mod
	mount -o bind $fonts_customization_mod $product_fonts_customization || true
fi
