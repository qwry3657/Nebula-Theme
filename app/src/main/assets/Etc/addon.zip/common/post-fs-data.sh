MODDIR=${0%/*}

